from pyspark.sql import SparkSession
from pyspark.sql import functions as F

spark = SparkSession.builder \
    .appName("BigData_PCD_Analise") \
    .getOrCreate()

print("🚀 Spark iniciado!")

# Caminhos reais (ajuste se precisar)
path_2022 = "dados/dataset_limpo_2022.csv"
path_2023 = "dados/dataset_limpo_2023.csv"
path_2024 = "dados/dataset_limpo_2024.csv"

# -------------------------------
# 1. Ler arquivos CSV
# -------------------------------
df2022 = spark.read.csv(path_2022, header=True, inferSchema=True)
df2023 = spark.read.csv(path_2023, header=True, inferSchema=True)
df2024 = spark.read.csv(path_2024, header=True, inferSchema=True)

print("📥 Arquivos carregados com sucesso!")
print("2022:", len(df2022.columns), "colunas")
print("2023:", len(df2023.columns), "colunas")
print("2024:", len(df2024.columns), "colunas")

# -------------------------------
# 2. Padronizar todas as colunas
# -------------------------------

# descobrir todas as colunas presentes em pelo menos um dataset
all_cols = set(df2022.columns) | set(df2023.columns) | set(df2024.columns)
all_cols = list(all_cols)

def add_missing_columns(df, all_cols):
    """
    Para cada coluna que NÃO existe no df, criamos uma coluna nula.
    Depois reordenamos.
    """
    for col in all_cols:
        if col not in df.columns:
            df = df.withColumn(col, F.lit(None))
    return df.select(all_cols)

df2022_fixed = add_missing_columns(df2022, all_cols)
df2023_fixed = add_missing_columns(df2023, all_cols)
df2024_fixed = add_missing_columns(df2024, all_cols)

# -------------------------------
# 3. Agora sim podemos unir
# -------------------------------
df = df2022_fixed.unionByName(df2023_fixed, allowMissingColumns=True) \
                 .unionByName(df2024_fixed, allowMissingColumns=True)

print("🧩 União concluída!")
print("Total de colunas:", len(df.columns))
print("Total de linhas:", df.count())

# -------------------------------
# 4. Limpeza básica
# -------------------------------
if "pcd" in df.columns:
    df = df.withColumn("pcd", F.upper(F.trim(F.col("pcd"))))

# -------------------------------
# 5. Exemplo de análise
# -------------------------------
if "pcd" in df.columns and "nivel_ensino" in df.columns:
    resultado = df.groupBy("pcd", "nivel_ensino").count()
    resultado.show(20)

# -------------------------------
# 6. Salvar resultado
# -------------------------------
output = "resultado_final"

df.coalesce(1).write \
    .mode("overwrite") \
    .option("header", True) \
    .csv(output)

print("💾 Resultado salvo em:", output)
print("✅ Pipeline finalizado!")
