import pandas as pd
import re

# =========================================================
# 1. Função para normalizar nomes de colunas confusos
# =========================================================
def limpar_nome_coluna(nome):
    nome = str(nome)

    # Remover parênteses, aspas e vírgulas
    nome = re.sub(r"[()']", "", nome)

    # Remover possíveis tuplas "P1_a , Idade"
    partes = nome.split(",")
    nome = partes[0].strip()

    # Remover duplos espaços
    nome = nome.strip()

    return nome


# =========================================================
# 2. Mapeamento universal (funciona com 2022, 2023 e 2024)
# =========================================================
mapeamento = {
    # ANOS ANTIGOS
    "P1_a": "idade",
    "P1_b": "genero",
    "P1_c": "cor_raca_etnia",
    "P1_d": "pcd",
    "P1_e": "exp_prof_prejudicada",
    "P1_e_1": "exp_nao_afetada",
    "P1_e_2": "exp_afetada_raca",
    "P1_e_3": "exp_afetada_genero",
    "P1_e_4": "exp_afetada_pcd",
    "P1_f": "aspectos_prejudicados",
    "P1_i_1": "uf_onde_mora",
    "P1_i": "estado_onde_mora",
    "P1_l": "nivel_ensino",
    "P1_m": "area_formacao",
    "P2_a": "situacao_trabalho",
    "P2_b": "setor",
    "P2_f": "cargo_atual",
    "P2_g": "nivel",
    "P2_h": "faixa_salarial",

    # ANO 2024
    "1.a_idade": "idade",
    "1.b_genero": "genero",
    "1.c_cor/raca/etnia": "cor_raca_etnia",
    "1.d_pcd": "pcd",
    "1.e_experiencia_profissional_prejudicada": "exp_prof_prejudicada",
    "1.e.1": "exp_nao_afetada",
    "1.e.2": "exp_afetada_raca",
    "1.e.3": "exp_afetada_genero",
    "1.e.4": "exp_afetada_pcd",
    "1.i.1": "uf_onde_mora",
    "1.i_estado_onde_mora": "estado_onde_mora",
    "1.l_nivel_de_ensino": "nivel_ensino",
    "1.m_área_de_formação": "area_formacao",
    "2.a_situação_de_trabalho": "situacao_trabalho",
    "2.b_setor": "setor",
    "2.f_cargo_atual": "cargo_atual",
    "2.g_nivel": "nivel",
    "2.h_faixa_salarial": "faixa_salarial",
}


# =========================================================
# 3. Função para carregar, limpar e padronizar QUALQUER ANO
# =========================================================
def limpar_dataset(caminho, saida):
    print(f"\n🔄 Limpando arquivo: {caminho}")

    df = pd.read_csv(caminho, encoding="latin1", low_memory=False)

    # Normalizar todos os nomes das colunas
    df.columns = [limpar_nome_coluna(c) for c in df.columns]

    df_final = pd.DataFrame()

    # Para cada possível coluna mapeada
    for coluna_original, coluna_final in mapeamento.items():

        # Procurar qualquer coluna que contenha o nome esperado
        encontrada = [c for c in df.columns if coluna_original.lower() in c.lower()]

        if encontrada:
            df_final[coluna_final] = df[encontrada[0]]

    # Salvar saída
    df_final.to_csv(saida, index=False, encoding="latin1")

    print(f"✔ Finalizado → {saida}")
    print("✔ Colunas:", list(df_final.columns))


# =========================================================
# 4. Processar todos os anos
# =========================================================
limpar_dataset("State_of_data_2022.csv", "dataset_limpo_2022.csv")
limpar_dataset("State_of_data_2023.csv", "dataset_limpo_2023.csv")
limpar_dataset("State_of_data_2024.csv", "dataset_limpo_2024.csv")
