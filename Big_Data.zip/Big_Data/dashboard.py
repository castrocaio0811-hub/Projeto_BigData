import pandas as pd
import plotly.express as px
from dash import Dash, html, dcc

# -------------------------------------------------------------------
# 1. Ler o CSV final gerado pelo Spark
# -------------------------------------------------------------------

csv_path = "resultado_final/part-00000-9bbe77cc-7c68-4c40-80fa-47c6f170a24d-c000.csv"

df = pd.read_csv(csv_path, on_bad_lines='skip', engine='python')

# -------------------------------------------------------------------
# 2. Ajustes básicos
# -------------------------------------------------------------------
if "pcd" in df.columns:
    df["pcd"] = df["pcd"].astype(str).str.strip().str.upper()

if "nivel_ensino" in df.columns:
    df["nivel_ensino"] = df["nivel_ensino"].astype(str).str.strip()

# -------------------------------------------------------------------
# 3. Criar gráficos Plotly
# -------------------------------------------------------------------

# 1) Distribuição PCD x Não PCD
fig_pcd = px.histogram(
    df,
    x="pcd",
    title="Distribuição de PCDs no dataset",
    color="pcd",
)

# 2) Nível de ensino por PCD
fig_nivel = px.histogram(
    df,
    x="nivel_ensino",
    color="pcd",
    title="Nível de ensino por PCD / Não PCD",
    barmode="group"
)

# 3) Proporção PCD por escolaridade (pareto)
fig_pareto = px.bar(
    df.groupby(["nivel_ensino", "pcd"]).size().reset_index(name="count"),
    x="nivel_ensino",
    y="count",
    color="pcd",
    title="Comparação: Escolaridade entre PCD e Não PCD"
)

# -------------------------------------------------------------------
# 4. Criar Dashboard com Dash
# -------------------------------------------------------------------

app = Dash(__name__)

app.layout = html.Div([
    html.H1("Dashboard – Análise de PCDs (Spark + Plotly)", style={"textAlign": "center"}),

    dcc.Graph(figure=fig_pcd),

    dcc.Graph(figure=fig_nivel),

    dcc.Graph(figure=fig_pareto),
])

# Rodar
if __name__ == "__main__":
    app.run(debug=True, port=8050)
